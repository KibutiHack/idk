/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/UnlegitMC/FDPClient/
 */

package net.ccbluex.liquidbounce.injection.implementations;

public interface IMixinGuiSlot {

    void setListWidth(int listWidth);

    void setEnableScissor(boolean b);

}
